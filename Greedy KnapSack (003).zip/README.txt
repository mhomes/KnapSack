This is the Greedy KnapSack Project for CS 351 - Fall 2018
Project by: Allen Burris and Mathew Homes


included with this file are the following files:
TestRuns.txt - a file containing sample runs of KnapSackMain.cpp
TestFileGenerator.cpp - used to create test files (TestFile.txt) for KnapSackMain.cpp
KnapSackMain.cpp - the main program

Instructions:
	1. Compile and run TestFileGenerator.cpp or import your own TestFile.txt to create an input file
		or KnapSackMain.cpp
	2. Compile and run KnapSackMain.cpp

winning.